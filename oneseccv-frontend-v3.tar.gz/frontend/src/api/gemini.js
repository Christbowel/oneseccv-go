import { GEMINI_MODEL, GEMINI_API_BASE } from '../config'

function geminiFetch(apiKey, body) {
  const url = `${GEMINI_API_BASE}/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`
  return fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
}

export async function generateCV(apiKey, userData, instruction, templateSource, goalJob) {
  // ── Exact same prompt structure as original app.go ──
  const prompt = `You are the CV expert of OneSecCV.

USER DATA:
${userData}

TARGET POSITION: ${goalJob || ''}
ADDITIONAL INSTRUCTIONS: ${instruction || ''}

TYPST TEMPLATE SOURCE:
${templateSource}

STRICT TECHNICAL RULES:
- Return ONLY the raw Typst code, no markdown or explanation.
- Fill ALL sections with the provided user data.
- Escape @ as \\@ in email addresses.
- Use standard dashes (- or --) for date ranges.
- Do not invent any information not present in the user data.
- Use only these fonts: "New Computer Modern", "Liberation Sans", "Liberation Mono", "DejaVu Sans"`

  const res = await geminiFetch(apiKey, {
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.3, maxOutputTokens: 8192 },
  })

  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.error?.message || `Gemini error: ${res.status}`)
  }

  const data = await res.json()
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text
  if (!text) throw new Error('Empty AI engine response — model returned no candidates')
  return extractTypst(text)
}

// ── Same retry-fix logic as original app.go ──
export async function fixCompileError(apiKey, faultyCode, errorLog) {
  const prompt = `The following Typst code failed to compile.

ERROR:
${errorLog}

FAULTY CODE:
${faultyCode}

Fix ONLY the compilation error. Keep the same content and structure.
Return ONLY the fixed Typst code, no markdown.`

  const res = await geminiFetch(apiKey, {
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.2, maxOutputTokens: 8192 },
  })

  if (!res.ok) throw new Error('AI fix request failed')
  const data = await res.json()
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text
  if (!text) throw new Error('AI returned no fix')
  return extractTypst(text)
}

function extractTypst(raw) {
  // Strip markdown fences (same logic as original extractLatexBlock)
  raw = raw.replace(/```typst/g, '').replace(/```typ/g, '').replace(/```/g, '')
  return raw.trim()
}
